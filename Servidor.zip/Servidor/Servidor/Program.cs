﻿using System;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;

public class GameServer
{
    private TcpListener tcpListener;
    private Thread listenThread;
    private bool isRunning = false;
    private int port;

    private TcpClient player1;
    private TcpClient player2;
    private NetworkStream stream1;
    private NetworkStream stream2;

    private Random random;
    private int[] distribucionTerritorios;
    private string aliasJugador1 = "Jugador1";
    private string aliasJugador2 = "Jugador2";
    private string jugadorConTurno = "NEUTRO";

    // ✅ ESTRUCTURAS PERSONALIZADAS
    private Diccionario<string, int> tropasPorJugador = new Diccionario<string, int>();
    private Diccionario<string, int> territoriosPorJugador = new Diccionario<string, int>();
    private Diccionario<int, int> tropasPorTerritorio = new Diccionario<int, int>();
    private Diccionario<int, string> propietariosTerritorios = new Diccionario<int, string>();
    private ListaEnlazada<int> territoriosNeutros = new ListaEnlazada<int>();

    public GameServer(int port)
    {
        this.port = port;
        this.random = new Random();
        this.distribucionTerritorios = new int[42];

        InicializarSistema();
    }

    private void InicializarSistema()
    {
        Console.WriteLine("🎮 Inicializando servidor Risk...");

        // Reiniciar contadores
        territoriosPorJugador.Agregar("JUGADOR1", 0);
        territoriosPorJugador.Agregar("JUGADOR2", 0);
        territoriosPorJugador.Agregar("NEUTRO", 0);

        // ✅ FORZAR 40 TROPAS INICIALES
        tropasPorJugador.Agregar("JUGADOR1", 40);
        tropasPorJugador.Agregar("JUGADOR2", 40);
        tropasPorJugador.Agregar("NEUTRO", 40);

        // Inicializar todos los territorios con 1 tropa
        for (int i = 0; i < 42; i++)
        {
            tropasPorTerritorio.Agregar(i, 1);
        }
    }

    public void Start()
    {
        isRunning = true;
        tcpListener = new TcpListener(IPAddress.Any, port);
        listenThread = new Thread(new ThreadStart(ListenForClients));
        listenThread.IsBackground = true;
        listenThread.Start();

        Console.WriteLine($"🎮 Servidor Risk iniciado en puerto {port}");
        Console.WriteLine("Esperando 2 jugadores...");
    }

    private void ListenForClients()
    {
        tcpListener.Start();

        while (isRunning)
        {
            try
            {
                player1 = tcpListener.AcceptTcpClient();
                stream1 = player1.GetStream();
                Console.WriteLine("✅ Jugador 1 conectado");
                SendToClient(player1, "ID:JUGADOR1");

                player2 = tcpListener.AcceptTcpClient();
                stream2 = player2.GetStream();
                Console.WriteLine("✅ Jugador 2 conectado");
                SendToClient(player2, "ID:JUGADOR2");

                Console.WriteLine("⏳ Esperando aliases de los jugadores...");
                Thread.Sleep(1000);

                SendToAll($"JUGADOR1_ALIAS:{aliasJugador1}");
                SendToAll($"JUGADOR2_ALIAS:{aliasJugador2}");

                DistribuirTerritorios();
                IniciarFaseColocacion();

                Thread player1Thread = new Thread(() => HandleClient(player1, "JUGADOR1"));
                Thread player2Thread = new Thread(() => HandleClient(player2, "JUGADOR2"));
                player1Thread.Start();
                player2Thread.Start();

                SendToAll("INICIAR_JUEGO");
                Console.WriteLine("🎲 Partida Risk iniciada!");

            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error: {ex.Message}");
                if (isRunning) Thread.Sleep(1000);
            }
        }
    }

    private void DistribuirTerritorios()
    {
        Console.WriteLine("🎲 Distribuyendo 42 territorios entre 3 facciones...");

        // ✅ MEZCLAR TERRITORIOS USANDO ARRAY TEMPORAL (más eficiente)
        int[] todosTerritoriosArray = new int[42];
        for (int i = 0; i < 42; i++)
        {
            todosTerritoriosArray[i] = i;
        }

        // Mezclar array con Fisher-Yates
        for (int i = 41; i > 0; i--)
        {
            int j = random.Next(i + 1);
            int temp = todosTerritoriosArray[i];
            todosTerritoriosArray[i] = todosTerritoriosArray[j];
            todosTerritoriosArray[j] = temp;
        }

        // ✅ CONVERTIR A LISTAENLAZADA DESPUÉS DE MEZCLAR
        ListaEnlazada<int> todosTerritorios = new ListaEnlazada<int>();
        for (int i = 0; i < 42; i++)
        {
            todosTerritorios.Agregar(todosTerritoriosArray[i]);
        }

        // ✅ REINICIAR CONTADORES
        territoriosPorJugador.Actualizar("JUGADOR1", 0);
        territoriosPorJugador.Actualizar("JUGADOR2", 0);
        territoriosPorJugador.Actualizar("NEUTRO", 0);
        territoriosNeutros.Limpiar();
        propietariosTerritorios.Limpiar();

        // Distribuir 14 territorios a cada uno
        for (int i = 0; i < 42; i++)
        {
            string propietario;
            if (i < 14)
            {
                propietario = "JUGADOR1";
                territoriosPorJugador.Actualizar("JUGADOR1", territoriosPorJugador.Obtener("JUGADOR1") + 1);
            }
            else if (i < 28)
            {
                propietario = "JUGADOR2";
                territoriosPorJugador.Actualizar("JUGADOR2", territoriosPorJugador.Obtener("JUGADOR2") + 1);
            }
            else
            {
                propietario = "NEUTRO";
                territoriosPorJugador.Actualizar("NEUTRO", territoriosPorJugador.Obtener("NEUTRO") + 1);
                territoriosNeutros.Agregar(todosTerritoriosArray[i]); // Usar el array mezclado
            }

            int territorioId = todosTerritoriosArray[i]; // Usar el array mezclado
            distribucionTerritorios[territorioId] = propietario == "JUGADOR1" ? 1 : propietario == "JUGADOR2" ? 2 : 0;

            // ✅ GUARDAR PROPIETARIO EN DICCIONARIO
            propietariosTerritorios.Agregar(territorioId, propietario);

            // ✅ ENVIAR TERRITORIO CON 1 TROPA
            string mensaje = $"TERRITORIO_ASIGNADO:{territorioId},{propietario},1";
            SendToAll(mensaje);

            Console.WriteLine($"📍 Territorio {territorioId} -> {propietario} (1 tropa)");
        }

        Console.WriteLine("✅ Distribución completada:");
        Console.WriteLine($"   JUGADOR1: {territoriosPorJugador.Obtener("JUGADOR1")} territorios");
        Console.WriteLine($"   JUGADOR2: {territoriosPorJugador.Obtener("JUGADOR2")} territorios");
        Console.WriteLine($"   NEUTRO: {territoriosPorJugador.Obtener("NEUTRO")} territorios");
    }

    private void IniciarFaseColocacion()
    {
        Console.WriteLine("💂 Iniciando fase de colocación de tropas...");

        // ✅ SOLUCIÓN DEFINITIVA: FORZAR 26 TROPAS
        tropasPorJugador.Actualizar("JUGADOR1", 26);
        tropasPorJugador.Actualizar("JUGADOR2", 26);
        tropasPorJugador.Actualizar("NEUTRO", 26);

        Console.WriteLine($"📊 Tropas para colocar:");
        Console.WriteLine($"   JUGADOR1: {tropasPorJugador.Obtener("JUGADOR1")} tropas");
        Console.WriteLine($"   JUGADOR2: {tropasPorJugador.Obtener("JUGADOR2")} tropas");
        Console.WriteLine($"   NEUTRO: {tropasPorJugador.Obtener("NEUTRO")} tropas");

        // ✅ ENVIAR 26 TROPAS DIRECTAMENTE
        SendToClient(player1, "TROPAS_DISPONIBLES:26");
        SendToClient(player2, "TROPAS_DISPONIBLES:26");

        Console.WriteLine("📤 Enviado a ambos jugadores: TROPAS_DISPONIBLES:26");

        jugadorConTurno = "NEUTRO";
        Console.WriteLine($"🔄 Primer turno: {jugadorConTurno}");
        ProcesarTurnoNeutro();
    }

    private void ProcesarTurnoNeutro()
    {
        if (tropasPorJugador.Obtener("NEUTRO") > 0 && territoriosNeutros.Count > 0)
        {
            // ✅ OBTENER TERRITORIO ALEATORIO USANDO MÉTODOS DISPONIBLES
            int indiceTerritorio = random.Next(territoriosNeutros.Count);
            int territorioId = 0;

            // Recorrer la lista hasta el índice aleatorio
            for (int i = 0; i <= indiceTerritorio; i++)
            {
                territorioId = territoriosNeutros.Obtener(i);
            }

            // ✅ NEUTRO COLOCA 1 TROPA Y ACTUALIZA CONTADOR
            tropasPorJugador.Actualizar("NEUTRO", tropasPorJugador.Obtener("NEUTRO") - 1);
            tropasPorTerritorio.Actualizar(territorioId, tropasPorTerritorio.Obtener(territorioId) + 1);

            string mensajeActualizacion = $"TROPAS_ACTUALIZADAS:{territorioId},NEUTRO,{tropasPorTerritorio.Obtener(territorioId)}";
            SendToAll(mensajeActualizacion);

            Console.WriteLine($"🤖 NEUTRO colocó 1 tropa en territorio {territorioId} | Total: {tropasPorTerritorio.Obtener(territorioId)}");

            Thread.Sleep(1000);
            SiguienteTurno();
        }
        else
        {
            Console.WriteLine("🤖 NEUTRO ha terminado de colocar tropas");
            jugadorConTurno = "JUGADOR1";
            SendToClient(player1, "TURNO:ACTIVO");
            SendToClient(player2, "TURNO:ESPERA");
            SendToAll("FASE_COLOCACION:INICIADA");
        }
    }

    private void SiguienteTurno()
    {
        if (jugadorConTurno == "NEUTRO")
        {
            if (tropasPorJugador.Obtener("JUGADOR1") > 0)
            {
                jugadorConTurno = "JUGADOR1";
                SendToClient(player1, "TURNO:ACTIVO");
                SendToClient(player2, "TURNO:ESPERA");
                Console.WriteLine($"🔄 Turno cambiado a JUGADOR1");
            }
            else if (tropasPorJugador.Obtener("JUGADOR2") > 0)
            {
                jugadorConTurno = "JUGADOR2";
                SendToClient(player1, "TURNO:ESPERA");
                SendToClient(player2, "TURNO:ACTIVO");
                Console.WriteLine($"🔄 Turno cambiado a JUGADOR2");
            }
            else
            {
                ProcesarTurnoNeutro();
            }
        }
        else if (jugadorConTurno == "JUGADOR1")
        {
            if (tropasPorJugador.Obtener("JUGADOR2") > 0)
            {
                jugadorConTurno = "JUGADOR2";
                SendToClient(player1, "TURNO:ESPERA");
                SendToClient(player2, "TURNO:ACTIVO");
                Console.WriteLine($"🔄 Turno cambiado a JUGADOR2");
            }
            else if (tropasPorJugador.Obtener("NEUTRO") > 0)
            {
                jugadorConTurno = "NEUTRO";
                SendToClient(player1, "TURNO:ESPERA");
                SendToClient(player2, "TURNO:ESPERA");
                Console.WriteLine($"🔄 Turno cambiado a NEUTRO");
                ProcesarTurnoNeutro();
            }
            else
            {
                FinalizarFaseColocacion();
            }
        }
        else if (jugadorConTurno == "JUGADOR2")
        {
            if (tropasPorJugador.Obtener("NEUTRO") > 0)
            {
                jugadorConTurno = "NEUTRO";
                SendToClient(player1, "TURNO:ESPERA");
                SendToClient(player2, "TURNO:ESPERA");
                Console.WriteLine($"🔄 Turno cambiado a NEUTRO");
                ProcesarTurnoNeutro();
            }
            else if (tropasPorJugador.Obtener("JUGADOR1") > 0)
            {
                jugadorConTurno = "JUGADOR1";
                SendToClient(player1, "TURNO:ACTIVO");
                SendToClient(player2, "TURNO:ESPERA");
                Console.WriteLine($"🔄 Turno cambiado a JUGADOR1");
            }
            else
            {
                FinalizarFaseColocacion();
            }
        }
    }

    private void FinalizarFaseColocacion()
    {
        Console.WriteLine("🎉 Fase de colocación completada!");
        SendToAll("FASE_COLOCACION:COMPLETADA");

        jugadorConTurno = "JUGADOR1";
        SendToClient(player1, "TURNO:ACTIVO");
        SendToClient(player2, "TURNO:ESPERA");

        // ✅ TROPAS POR TURNO EN FASE NORMAL
        tropasPorJugador.Actualizar("JUGADOR1", 3);
        tropasPorJugador.Actualizar("JUGADOR2", 3);
        SendToClient(player1, $"TROPAS_DISPONIBLES:{tropasPorJugador.Obtener("JUGADOR1")}");
        SendToClient(player2, $"TROPAS_DISPONIBLES:{tropasPorJugador.Obtener("JUGADOR2")}");

        Console.WriteLine($"🔄 Fase normal iniciada - Turno: JUGADOR1");
    }

    private void HandleClient(TcpClient client, string playerId)
    {
        byte[] buffer = new byte[4096];
        NetworkStream stream = client.GetStream();

        while (isRunning && client.Connected)
        {
            try
            {
                if (!stream.DataAvailable)
                {
                    Thread.Sleep(50);
                    continue;
                }

                int bytesRead = stream.Read(buffer, 0, buffer.Length);
                if (bytesRead == 0) break;

                string message = Encoding.UTF8.GetString(buffer, 0, bytesRead).Trim();
                Console.WriteLine($"📨 {playerId} dice: {message}");

                if (message.StartsWith("ALIAS:"))
                {
                    ProcesarAlias(playerId, message);
                }
                else if (message.StartsWith("COLOCAR_TROPAS:"))
                {
                    ProcesarColocacionTropas(playerId, message);
                }
                else if (message == "TERMINAR_TURNO")
                {
                    ProcesarFinTurno(playerId);
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"❌ Error con {playerId}: {ex.Message}");
                break;
            }
        }

        CleanupPlayerConnection(playerId, client);
    }

    private void ProcesarAlias(string playerId, string mensaje)
    {
        string alias = mensaje.Substring(6);
        if (playerId == "JUGADOR1")
        {
            aliasJugador1 = alias;
            SendToAll($"JUGADOR1_ALIAS:{aliasJugador1}");
        }
        else
        {
            aliasJugador2 = alias;
            SendToAll($"JUGADOR2_ALIAS:{aliasJugador2}");
        }
        Console.WriteLine($"📛 {playerId} se llama: {alias}");
    }

    private void ProcesarColocacionTropas(string playerId, string mensaje)
    {
        Console.WriteLine($"🔍 DEBUG COLOCACIÓN: Jugador {playerId}, Mensaje: {mensaje}");

        if (playerId != jugadorConTurno)
        {
            Console.WriteLine($"❌ {playerId} intentó colocar tropas fuera de turno");
            SendToClient(GetClientByPlayerId(playerId), "ERROR:No es tu turno");
            return;
        }

        try
        {
            string[] partes = mensaje.Split(':');
            string[] datos = partes[1].Split(',');

            int territorioId = int.Parse(datos[0]);
            int cantidad = int.Parse(datos[1]);

            // ✅ VERIFICAR QUE HAY SUFICIENTES TROPAS
            int tropasActuales = tropasPorJugador.Obtener(playerId);
            if (cantidad > tropasActuales)
            {
                Console.WriteLine($"❌ {playerId} intentó colocar {cantidad} tropas pero solo tiene {tropasActuales}");
                SendToClient(GetClientByPlayerId(playerId), "ERROR:No tienes suficientes tropas");
                return;
            }

            // ✅ VERIFICAR PROPIEDAD DEL TERRITORIO - USANDO DICCIONARIO
            string propietarioActual = propietariosTerritorios.Obtener(territorioId);
            Console.WriteLine($"🔍 DEBUG: Territorio {territorioId} pertenece a '{propietarioActual}'");

            if (propietarioActual == playerId)
            {
                // ✅ RESTAR TROPAS DISPONIBLES
                tropasPorJugador.Actualizar(playerId, tropasActuales - cantidad);

                // ✅ SUMAR TROPAS AL TERRITORIO
                tropasPorTerritorio.Actualizar(territorioId, tropasPorTerritorio.Obtener(territorioId) + cantidad);

                string mensajeActualizacion = $"TROPAS_ACTUALIZADAS:{territorioId},{playerId},{tropasPorTerritorio.Obtener(territorioId)}";
                SendToAll(mensajeActualizacion);

                // ✅ ENVIAR NUEVAS TROPAS DISPONIBLES
                SendToClient(GetClientByPlayerId(playerId), $"TROPAS_DISPONIBLES:{tropasPorJugador.Obtener(playerId)}");

                Console.WriteLine($"💂 {playerId} colocó {cantidad} tropas en territorio {territorioId} | Total: {tropasPorTerritorio.Obtener(territorioId)} | Restantes: {tropasPorJugador.Obtener(playerId)}");
                Console.WriteLine($"🔍 DEBUG: Enviando -> {mensajeActualizacion}");

                // ✅ PASAR AL SIGUIENTE TURNO
                SiguienteTurno();
            }
            else
            {
                Console.WriteLine($"❌ {playerId} intentó colocar en territorio de {propietarioActual}: {territorioId}");
                SendToClient(GetClientByPlayerId(playerId), "ERROR:Territorio no te pertenece");
            }
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Error procesando colocación: {ex.Message}");
        }
    }

    private string GetPropietarioTerritorio(int territorioId)
    {
        // ✅ USAR EL DICCIONARIO PARA MÁS CONFIABILIDAD
        if (propietariosTerritorios.ContieneClave(territorioId))
        {
            return propietariosTerritorios.Obtener(territorioId);
        }

        // ✅ FALLBACK AL ARRAY ORIGINAL
        int propietarioId = distribucionTerritorios[territorioId];
        return propietarioId == 1 ? "JUGADOR1" : propietarioId == 2 ? "JUGADOR2" : "NEUTRO";
    }

    private void ProcesarFinTurno(string playerId)
    {
        if (playerId != jugadorConTurno)
        {
            Console.WriteLine($"❌ {playerId} intentó terminar turno fuera de turno");
            SendToClient(GetClientByPlayerId(playerId), "ERROR:No es tu turno");
            return;
        }

        if (tropasPorJugador.Obtener(playerId) > 0)
        {
            Console.WriteLine($"❌ {playerId} intentó terminar turno con {tropasPorJugador.Obtener(playerId)} tropas restantes");
            SendToClient(GetClientByPlayerId(playerId), $"ERROR:Aún tienes {tropasPorJugador.Obtener(playerId)} tropas por colocar");
            return;
        }

        string nuevoTurno = (playerId == "JUGADOR1") ? "JUGADOR2" : "JUGADOR1";
        jugadorConTurno = nuevoTurno;

        tropasPorJugador.Actualizar(nuevoTurno, 3);

        SendToClient(player1, $"TURNO:{(nuevoTurno == "JUGADOR1" ? "ACTIVO" : "ESPERA")}");
        SendToClient(player2, $"TURNO:{(nuevoTurno == "JUGADOR2" ? "ACTIVO" : "ESPERA")}");

        SendToClient(GetClientByPlayerId(nuevoTurno), $"TROPAS_DISPONIBLES:{tropasPorJugador.Obtener(nuevoTurno)}");

        Console.WriteLine($"🔄 Turno cambiado a {nuevoTurno} con {tropasPorJugador.Obtener(nuevoTurno)} tropas");
    }

    private TcpClient GetClientByPlayerId(string playerId)
    {
        return playerId == "JUGADOR1" ? player1 : player2;
    }

    private void SendToClient(TcpClient client, string message)
    {
        try
        {
            if (client == null || !client.Connected) return;

            NetworkStream stream = client.GetStream();
            byte[] data = Encoding.UTF8.GetBytes(message + "\n");
            stream.Write(data, 0, data.Length);
        }
        catch (Exception ex)
        {
            Console.WriteLine($"❌ Error enviando: {ex.Message}");
        }
    }

    private void SendToAll(string message)
    {
        SendToClient(player1, message);
        SendToClient(player2, message);
    }

    private void CleanupPlayerConnection(string playerId, TcpClient client)
    {
        try
        {
            client?.Close();
            if (playerId == "JUGADOR1") player1 = null;
            else if (playerId == "JUGADOR2") player2 = null;
            Console.WriteLine($"🔌 {playerId} desconectado");
        }
        catch (Exception ex)
        {
            Console.WriteLine($"⚠️ Error limpiando {playerId}: {ex.Message}");
        }
    }

    public void Stop()
    {
        isRunning = false;
        tcpListener?.Stop();
        player1?.Close();
        player2?.Close();
        Console.WriteLine("🛑 Servidor detenido");
    }

    public static void Main(string[] args)
    {
        GameServer server = new GameServer(7777);
        server.Start();

        Console.WriteLine("Presiona 'Q' para detener el servidor...");
        while (Console.ReadKey().Key != ConsoleKey.Q) { }

        server.Stop();
    }
}
